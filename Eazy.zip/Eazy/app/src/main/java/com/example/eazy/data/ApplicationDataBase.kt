package com.melimu.exam.data

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteOpenHelper
import com.melimu.exam.model.User
import com.melimu.exam.util.ApplicationConstant

@Database(
    entities = [User::class],
    version = 3,
    exportSchema = false
)
abstract class ApplicationDataBase: RoomDatabase(){
    abstract fun userDao(): UserDAO?

    companion object {

        @Volatile private var instance: ApplicationDataBase? = null
        fun getDataseClient(context: Context) : ApplicationDataBase {

            if (instance != null) return instance!!

            synchronized(this) {

                instance = Room
                    .databaseBuilder(context, ApplicationDataBase::class.java, ApplicationConstant.DB_NAME)
                    .fallbackToDestructiveMigration()
                    .build()

                return instance!!
            }
        }

    }


}