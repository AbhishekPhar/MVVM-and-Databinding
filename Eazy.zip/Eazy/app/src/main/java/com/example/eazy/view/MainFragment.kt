package com.example.eazy.view

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import com.example.eazy.R
import com.example.eazy.databinding.MainFragmentBinding


/**
 * A simple [Fragment] subclass.
 * Use the [MainFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class MainFragment : Fragment() {
    private var views: View? = null
    private var binding: MainFragmentBinding? = null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate<ViewDataBinding>(inflater,
            R.layout.main_fragment, container, false) as MainFragmentBinding?
        views = binding!!.root
        return views
    }

    override fun onResume() {
        super.onResume()
        Log.d("AbhiPhar","----OnResume()")
    }
}