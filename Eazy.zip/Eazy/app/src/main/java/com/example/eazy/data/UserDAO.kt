package com.melimu.exam.data

import androidx.room.*
import com.melimu.exam.model.User
@Dao
interface UserDAO {
    @Insert
    fun addUser(user: User?): Long

    @Update
    fun updateUser(user: User?)

    @Delete
    fun deleteUser(user: User?)

    @Query("DELETE FROM user")
    fun deleteAllUser()

    @Query("SELECT * FROM user WHERE uid = :uid ")
    fun getUser(uid: String?): List<User?>?

    @Query("SELECT * FROM user")
    fun getALLUser(): List<User?>?
}